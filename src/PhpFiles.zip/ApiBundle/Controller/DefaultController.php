<?php

namespace ApiBundle\Controller;

use AppBundle\Entity\User;
use EvenementBundle\Entity\Participation;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

class DefaultController extends Controller
{
    public function indexAction()
    {
        return $this->render('ApiBundle:Default:index.html.twig');
    }
    public function loginAction($username,$password)
    {

        $em = $this->getDoctrine()->getManager();
        $query = $em->createQuery("SELECT u FROM AppBundle:User u WHERE u.username = :username");
        $query->setParameter('username', $username);
        $user = $query->getOneOrNullResult();

        if ($user) {
            // Get the encoder for the users password
            $encoder_service = $this->get('security.encoder_factory');
            $encoder = $encoder_service->getEncoder($user);

            // Note the difference
            if ($encoder->isPasswordValid($user->getPassword(), $password, $user->getSalt()))
            {
                //login valid
                $normalizer = new ObjectNormalizer();

                $normalizer->setCircularReferenceHandler(function ($ev) {
                    return $ev;
                });
                $format="Y-m-d";
                $serializer = new Serializer(array(new DateTimeNormalizer($format), $normalizer));
//                $serializer = new Serializer([new ObjectNormalizer()]);
                $formatted = $serializer->normalize($user);
                return new JsonResponse($formatted);
            }

            else
            {
                //password invalid
                $u = new User();
                //die("username valid but password is not");
                $serializer = new Serializer([new ObjectNormalizer()]);
                $formatted = $serializer->normalize($u);
                return new JsonResponse($formatted);
            }
        }
        else
        {
            //username invalid
            $u = new User();
            $serializer = new Serializer([new ObjectNormalizer()]);
            $formatted = $serializer->normalize($u);
            return new JsonResponse($formatted);
        }
    }

    public function modifierUserPhotoAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $user = $em->getRepository('AppBundle:User')->find($request->get('user'));
        $user->setImage($request->get('image_id'));
        $em->persist($user);
        $em->flush();
        return new JsonResponse("OK");
    }
    public function modifierUserAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
            $user = $em->getRepository('AppBundle:User')->find($request->get('user'));
        $em = $this->getDoctrine()->getManager();
        $user->setNom($request->get('nom'));
        $user->setPrenom($request->get('prenom'));
        $user->setPhone($request->get('tel'));
        $em->persist($user);
        $em->flush();
        return new JsonResponse("OK");
    }
///////////////////////////// evenment ///////////////////////////
    public function serviceAction()
    {
        $em= $this->getDoctrine()->getManager();
        $evenement = $em->getRepository("EvenementBundle:Evenement")->findAll();
        $normalizer = new ObjectNormalizer();
        //$normalizer->setIgnoredAttributes(array('user'));
        $serializer=new Serializer(array(new DateTimeNormalizer(),$normalizer));
        $dataarray = array("cat"=>$evenement);
        $data=$serializer->normalize($evenement, null, array('attributes' => array('id','nbreParticipants','nom','nomImage')));
        return new JsonResponse($data);
    }
    public function service2Action($id)
    {
        $em= $this->getDoctrine()->getManager();
        $evenement = $em->getRepository("EvenementBundle:Evenement")->find($id);
        $normalizer = new ObjectNormalizer();
        $serializer=new Serializer(array(new DateTimeNormalizer(),$normalizer));
        $dataarray = array("cat"=>$evenement);
        $data=$serializer->normalize($evenement, null, array('attributes' => array('id','type','nom','nomImage','datesortie','lieu','nbreParticipants')));
        return new JsonResponse($data);
    }

    public function partAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $event=$em->getRepository("EvenementBundle:Evenement")->find($id);
        var_dump($event);
        $event->setNbplaces($event->getNbplaces() - "1");
        $em->persist($event);
        $em->flush();
        $response = new Response();
        $response->setContent("ok");
        return $response;
    }
    public function checkParticipationAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $user = $em->getRepository('AppBundle:User')->find($request->get('user'));
        $id = $request->get("ide");
        $evenement=$em->getRepository("EvenementBundle:Evenement")->find($id);
        dump($user);
        dump($id);
        $participTest = $this->getDoctrine()->getRepository("EvenementBundle:Participation")->findP($evenement,$user);
        if($participTest == null)
            return new JsonResponse("OK");
        else
            return new JsonResponse("NO");
    }
    public function ParticipationAction(Request $request,$id)
    {
        $em= $this->getDoctrine()->getManager();
        $participation = new Participation();
        $user = $em->getRepository('AppBundle:User')->find($request->get("user"));
        $evenement=$em->getRepository("EvenementBundle:Evenement")->find($request->get("event"));
        $participTest = $this->getDoctrine()->getRepository("EvenementBundle:Participation")->findP($evenement,$user);
        if ($participTest == null ) {
            $evenement->setNbreParticipants($evenement->getNbreParticipants() - "1");
            $participation->setIdEvenement($evenement);
            $participation->setValidation("False");
            $participation->setIdUser($user);
            $em->persist($participation);
            $em->flush();
            return new JsonResponse("ok");
        }
        else {
            return new JsonResponse("no");
        }
    }
}
