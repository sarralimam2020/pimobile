<?php

namespace ApiBundle\Controller;

use AppBundle\Entity\User;
use LocationBundle\Entity\Contract;
use LocationBundle\Entity\Location;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

class RentController extends Controller
{
    public function indexAction()
    {
        return $this->render('ApiBundle:Default:index.html.twig');
    }

    public function AffichRentAction()
    {
        $em= $this->getDoctrine()->getManager();
        $evenement = $em->getRepository("LocationBundle:Location")->findAll();
        $normalizer = new ObjectNormalizer();
        //$normalizer->setIgnoredAttributes(array('user'));
        $serializer=new Serializer(array(new DateTimeNormalizer(),$normalizer));
        $dataarray = array("cat"=>$evenement);
        $data=$serializer->normalize($evenement, null, array('attributes' => array('id','dailyPrice','imageId','matricule','marque')));
        return new JsonResponse($data);
    }

    public function detailsRentAction($id)
    {
        $em= $this->getDoctrine()->getManager();
        $evenement = $em->getRepository("LocationBundle:Location")->find($id);
        $normalizer = new ObjectNormalizer();
        $serializer=new Serializer(array(new DateTimeNormalizer(),$normalizer));
        $dataarray = array("cat"=>$evenement);
        $data=$serializer->normalize($evenement, null, array('attributes' => array('id','owner','dailyPrice','imageId','matricule','marque','model','category','puissance','type')));
        return new JsonResponse($data);
    }

    public function addContractAction(Request $request)
    {

        $em = $this->getDoctrine()->getManager();
        $casting = new Contract();
        $user = $em->getRepository('AppBundle:User')->find($request->get('user'));
        $casting->setUtilisateur("HuntKingdom");
        $casting->setDateDebutLocation(new \DateTime(($request->get('Date'))));
        $casting->setDateFinLocation(new \DateTime(($request->get('Date'))));
        $casting->setPhonenumber($user->getPhone());

        $em->persist($casting);
        $em->flush();
        $serializer = new Serializer([new ObjectNormalizer()]);
        $formatted = $serializer->normalize($casting);
        return new JsonResponse($formatted);


    }

}
