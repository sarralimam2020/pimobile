<?php

namespace ApiBundle\Controller;

use ShopBundle\Entity\Category;
use ShopBundle\Entity\Panier;
use ShopBundle\Entity\Produit;
use ShopBundle\Entity\Region;
use ShopBundle\Entity\Reviews;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

class ShopController extends Controller
{

    public function indexAction(Request $request)
    {

        $products = $this->getDoctrine()->getRepository('ShopBundle:Produit')->findAll();
        $em = $this->getDoctrine()->getManager();
        $normalizer = new ObjectNormalizer();
        $serializer = new Serializer(array(new DateTimeNormalizer(), $normalizer));
        $data = $serializer->normalize($products, null, array('attributes' => array('id', 'nom', 'description', 'prix', 'quantity', 'imageId', 'date')));
        return new JsonResponse($data);
    }

    public function detailsAction($id)
    {
        $em= $this->getDoctrine()->getManager();
        $evenement = $em->getRepository("ShopBundle:Produit")->find($id);
        $normalizer = new ObjectNormalizer();
        $serializer=new Serializer(array(new DateTimeNormalizer(),$normalizer));
        $data=$serializer->normalize($evenement, null, array('attributes' => array('id','nom','description','prix','imageId','quantity','date')));
        return new JsonResponse($data);
    }
    public function myorderAction()
    {
        if ($this->container->get('security.authorization_checker')->isGranted('IS_AUTHENTICATED_FULLY')) {
            $user = $this->container->get('security.token_storage')->getToken()->getUser();
            $panelist = $this->getDoctrine()->getRepository('ShopBundle:Order')->findByUser($user);
            return $this->render('@Shop/Default/orders.html.twig', array('orders' => $panelist, 'total' => 0));
        }
        return $this->redirectToRoute('home');
    }

    public function addToPanierAction(Request $request)
    {

        $em = $this->getDoctrine()->getManager();
        $casting = new Panier();
        $prod= $em->getRepository("ShopBundle:Produit")->find($request->get('ProduitId'));
        $user= $em->getRepository("AppBundle:User")->find($request->get('userId'));
        $casting->setProduitP($prod);
        $casting->setUser($user);

        $casting->setDateP(new \DateTime(($request->get('Date'))));
        $casting->setQuantite($request->get('Qantity'));
        $casting->setPrix($request->get('Prix'));


        $em->persist($casting);
        $em->flush();
        $serializer = new Serializer([new ObjectNormalizer()]);
        $formatted = $serializer->normalize($casting);
        return new JsonResponse($formatted);


    }
public function PanierAction(Request $request)
{
    $em= $this->getDoctrine()->getManager();
    $evenement = $em->getRepository("ShopBundle:Panier")->findByUser($request->get('userId'));
    $normalizer = new ObjectNormalizer();
    //$normalizer->setIgnoredAttributes(array('user'));
    $serializer=new Serializer(array(new DateTimeNormalizer(),$normalizer));
    $dataarray = array("cat"=>$evenement);
    $data=$serializer->normalize($evenement, null, array('attributes' => array('id','userId','produitId','quantite','prix','dateP')));
    return new JsonResponse($data);
}

}
